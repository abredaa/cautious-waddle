package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class MainActivity extends AppCompatActivity {
    private ListView carsList;
    CarAdapter carAdapter;
    private EditText addTxt;
    private Button addCarBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addCarBtn = findViewById(R.id.addBtn);
        addTxt = findViewById(R.id.addCar);


       
        carsList = findViewById(R.id.lv_list_cars);
       
        carAdapter = new CarAdapter(this);
        
        carAdapter.addCar("Dacia",R.drawable.lab5_car_icon);
        carAdapter.addCar("Seat",R.drawable.lab5_car_icon);
        carAdapter.addCar("Opel",R.drawable.lab5_car_icon);
        carAdapter.addCar("Audi",R.drawable.lab5_car_icon);
       
        carsList.setAdapter(carAdapter);


        addCarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newCar = addTxt.getText().toString();
                carAdapter.addCar(newCar,R.drawable.lab5_car_icon);
                addTxt.setText("");
                carAdapter.notifyDataSetChanged();

            }
        });



    }
}

class Car {
    String modele;
    int imgResource;
}

class TagCar {
    TextView modele;
    ImageView img;
}
